# CS591-S2: Deep Learning

Spring 2017, Boston University

Instructors: Brian Kulis and Kate Saenko

[Problem Set 2](https://github.com/kunhe/cs591s2/blob/master/pset2.ipynb)
